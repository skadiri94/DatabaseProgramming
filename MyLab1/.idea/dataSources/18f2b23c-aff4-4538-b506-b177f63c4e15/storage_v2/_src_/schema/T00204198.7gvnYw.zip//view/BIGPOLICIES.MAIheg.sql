create view BIGPOLICIES as
SELECT Policy_No, Premium_Amt, Type
FROM Policies
WHERE Premium_Amt > 50
ORDER BY Premium_Amt DESC
/

