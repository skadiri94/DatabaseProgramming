create view POLICYHOLDER as
SELECT Policy_No,Type, Surname, Forename
FROM Policies P JOIN Holders H ON P.Holder_ID = H.Holder_ID
/

